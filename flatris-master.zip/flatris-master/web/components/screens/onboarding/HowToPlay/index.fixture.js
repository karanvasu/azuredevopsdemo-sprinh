// @flow

import React from 'react';
import HowToPlay from '.';

export default (
  <HowToPlay disabled={false} onNext={() => console.log('Next')} />
);
