// @flow

import React from 'react';
import FlatrisIntro from '.';

export default <FlatrisIntro onNext={() => console.log('Next')} />;
