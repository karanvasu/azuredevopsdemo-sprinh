// @flow

import React from 'react';
import Loading from '.';

export default <Loading />;
