// @flow

import React from 'react';
import PlayerInfo from '..';

export default (
  <PlayerInfo
    player={null}
    wins={null}
    isPlayer1={true}
    showReadyState={false}
  />
);
