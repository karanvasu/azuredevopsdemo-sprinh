// @flow

export type ComponentError = {
  message: string,
  stack: string,
};
