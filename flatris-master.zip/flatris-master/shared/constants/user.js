export const MAX_NAME_LENGTH = 14;
