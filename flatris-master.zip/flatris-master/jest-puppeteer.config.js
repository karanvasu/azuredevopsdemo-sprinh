module.exports = {
  launch: {
    args: ['--no-sandbox'],
  },
};
